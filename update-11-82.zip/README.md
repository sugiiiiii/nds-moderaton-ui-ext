<img alt="logo" src="https://raw.githubusercontent.com/sugiiiiii/nds-moderaton-ui-ext/main/readme/logo.svg" height="150" />

## Présentation
Projet totallement indépendant de [Brainly](https://brainly.com/), l'objectif est de rendre l'expérience de modération sur [nosdevoirs](https://Nosdevoirs.fr/) plus agréable.
Cela se traduit par des modifications visuelles par l'injection de CSS ainsi que la suppression et l'ajout de quelques éléments.
L'extension n'analyse, garde, utilise aucune donnée personnelle et ne fait qu'injecter des fichiers lorsque le site est visité.

## Installer l'extension
Désormais sur le [🔗 Chrome App Store](https://chrome.google.com/webstore/detail/nds-updated-moderation/gaenahlodadnkekokadopllphopejaba), régulièrement mise à jour.
<br>

## Aperçus
<img alt="render-1" src="https://raw.githubusercontent.com/sugiiiiii/nds-moderaton-ui-ext/main/readme/new-buttons.png" height="500" />
<img alt="render-2" src="https://raw.githubusercontent.com/sugiiiiii/nds-moderaton-ui-ext/main/readme/new-links.png" height="500" />
<img alt="render-3" src="https://raw.githubusercontent.com/sugiiiiii/nds-moderaton-ui-ext/main/readme/moderation-popup.png" height="500" />
<img alt="render-4" src="https://raw.githubusercontent.com/sugiiiiii/nds-moderaton-ui-ext/main/readme/mod-panel.png" height="500" />
<img alt="render-5" src="https://raw.githubusercontent.com/sugiiiiii/nds-moderaton-ui-ext/main/readme/inbox.png" height="500" />
